create definer = root@localhost view studentfinalperformance as
select `s`.`id`                AS `student_id`,
       `s`.`name`              AS `student_name`,
       `c`.`id`                AS `course_id`,
       `c`.`course_name`       AS `course_name`,
       `fq`.`title`            AS `question_title`,
       `fq`.`marks`            AS `max_marks`,
       `sfm`.`marks_obtained`  AS `marks_obtained`,
       `spl2`.`co`.`co_number` AS `co_number`,
       `spl2`.`po`.`po_number` AS `po_number`
from (((((((`spl2`.`student` `s` join `spl2`.`enrollment` `e`
            on ((`s`.`id` = `e`.`student_id`))) join `spl2`.`course` `c`
           on ((`e`.`course_id` = `c`.`id`))) join `spl2`.`final` `f`
          on ((`c`.`id` = `f`.`course_id`))) join `spl2`.`finalquestion` `fq`
         on ((`f`.`id` = `fq`.`final_id`))) left join `spl2`.`studentfinalmarks` `sfm`
        on (((`s`.`id` = `sfm`.`student_id`) and (`fq`.`id` = `sfm`.`final_question_id`)))) join `spl2`.`co`
       on ((`fq`.`co_id` = `spl2`.`co`.`id`))) join `spl2`.`po` on ((`fq`.`po_id` = `spl2`.`po`.`id`)));

