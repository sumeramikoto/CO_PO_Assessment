create definer = root@localhost view studentmidperformance as
select `s`.`id`                AS `student_id`,
       `s`.`name`              AS `student_name`,
       `c`.`course_code`       AS `course_id`,
       `c`.`course_name`       AS `course_name`,
       `mq`.`title`            AS `question_title`,
       `mq`.`marks`            AS `max_marks`,
       `smm`.`marks_obtained`  AS `marks_obtained`,
       `spl2`.`co`.`co_number` AS `co_number`,
       `spl2`.`po`.`po_number` AS `po_number`
from (((((((`spl2`.`student` `s` join `spl2`.`enrollment` `e`
            on ((`s`.`id` = `e`.`student_id`))) join `spl2`.`course` `c`
           on ((`e`.`course_id` = `c`.`course_code`))) join `spl2`.`mid` `m`
          on ((`c`.`course_code` = `m`.`course_id`))) join `spl2`.`midquestion` `mq`
         on ((`m`.`id` = `mq`.`mid_id`))) left join `spl2`.`studentmidmarks` `smm`
        on (((`s`.`id` = `smm`.`student_id`) and (`mq`.`id` = `smm`.`mid_question_id`)))) join `spl2`.`co`
       on ((`mq`.`co_id` = `spl2`.`co`.`id`))) join `spl2`.`po` on ((`mq`.`po_id` = `spl2`.`po`.`id`)));

