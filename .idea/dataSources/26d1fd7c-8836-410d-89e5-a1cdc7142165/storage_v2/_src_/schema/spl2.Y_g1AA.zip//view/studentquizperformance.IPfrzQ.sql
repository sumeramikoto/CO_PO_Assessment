create definer = root@localhost view studentquizperformance as
select `s`.`id`                AS `student_id`,
       `s`.`name`              AS `student_name`,
       `c`.`course_code`       AS `course_id`,
       `c`.`course_name`       AS `course_name`,
       `q`.`quiz_number`       AS `quiz_number`,
       `qq`.`title`            AS `question_title`,
       `qq`.`marks`            AS `max_marks`,
       `sqm`.`marks_obtained`  AS `marks_obtained`,
       `spl2`.`co`.`co_number` AS `co_number`,
       `spl2`.`po`.`po_number` AS `po_number`
from (((((((`spl2`.`student` `s` join `spl2`.`enrollment` `e`
            on ((`s`.`id` = `e`.`student_id`))) join `spl2`.`course` `c`
           on ((`e`.`course_id` = `c`.`course_code`))) join `spl2`.`quiz` `q`
          on ((`c`.`course_code` = `q`.`course_id`))) join `spl2`.`quizquestion` `qq`
         on ((`q`.`id` = `qq`.`quiz_id`))) left join `spl2`.`studentquizmarks` `sqm`
        on (((`s`.`id` = `sqm`.`student_id`) and (`qq`.`id` = `sqm`.`quiz_question_id`)))) join `spl2`.`co`
       on ((`qq`.`co_id` = `spl2`.`co`.`id`))) join `spl2`.`po` on ((`qq`.`po_id` = `spl2`.`po`.`id`)));

